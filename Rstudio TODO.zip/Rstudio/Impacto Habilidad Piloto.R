###############################################################################
# 1) Librerías necesarias
###############################################################################
library(dplyr)
library(ggplot2)

###############################################################################
# 2) Crear variable de clasificación de incertidumbre
###############################################################################
# Clasificar el nivel de incertidumbre: "Baja" si Factor_Imprevisibilidad es menor
# que la mediana, "Alta" en caso contrario.
df_modelo <- df_modelo %>%
  mutate(Uncertainty_Level = if_else(
    Factor_Imprevisibilidad < median(Factor_Imprevisibilidad, na.rm = TRUE),
    "Baja", "Alta"
  ))

# Asegurarse de que la variable de incertidumbre es un factor con orden lógico:
df_modelo$Uncertainty_Level <- factor(df_modelo$Uncertainty_Level, levels = c("Baja", "Alta"))

###############################################################################
# 3) Gráfico de dispersión facetado por nivel de incertidumbre
###############################################################################
ggplot(df_modelo, aes(x = Pilot, y = Prediccion_Clasificacion)) +
  # Los puntos muestran la relación entre la habilidad del piloto y la predicción de clasificación.
  # El tamaño y color de los puntos indican el nivel de incertidumbre.
  geom_point(aes(size = Factor_Imprevisibilidad, color = Factor_Imprevisibilidad), alpha = 0.8) +
  
  # Se añade una línea de regresión lineal punteada para resaltar la tendencia en cada panel.
  geom_smooth(method = "lm", se = FALSE, color = "black", linetype = "dashed", linewidth = 1.1) +
  
  # Escala de color: azul para baja incertidumbre, rojo para alta.
  scale_color_gradient(low = "#56B1F7", high = "#FF0000",
                       name = "Incertidumbre",
                       breaks = c(0, 0.5, 1),
                       labels = c("Baja", "Media", "Alta")) +
  scale_size_continuous(range = c(2, 8),
                        name = "Incertidumbre") +
  
  # Títulos, subtítulos y etiquetas: se elige un lenguaje que resalte la importancia comercial del hallazgo.
  labs(
    title    = "El Valor del Piloto se Multiplica en Escenarios de Alta Incertidumbre",
    subtitle = "Comparación de la habilidad del piloto y la predicción de clasificación\nsegún el nivel de incertidumbre del circuito",
    x        = "Habilidad del Piloto (Simulada)",
    y        = "Predicción de Clasificación",
    caption  = "Fuente: Simulaciones Internas - Estrategia & Marketing"
  ) +
  
  # Facetamos el gráfico según el nivel de incertidumbre (Baja vs. Alta)
  facet_wrap(~ Uncertainty_Level) +
  
  # Tema limpio y moderno
  theme_minimal(base_size = 14) +
  theme(
    plot.title    = element_text(face = "bold", size = 18, color = "#333333"),
    plot.subtitle = element_text(size = 12, color = "#666666"),
    legend.position = "right"
  ) +
  
  # Opcional: agregar una anotación en cada panel para enfatizar la diferencia
  geom_text(data = df_modelo %>% group_by(Uncertainty_Level) %>% 
              summarise(x = median(Pilot, na.rm = TRUE),
                        y = max(Prediccion_Clasificacion, na.rm = TRUE)),
            aes(x = x, y = y, label = paste("Impacto notable en", Uncertainty_Level)), 
            inherit.aes = FALSE,
            vjust = -1, size = 4, fontface = "italic")

