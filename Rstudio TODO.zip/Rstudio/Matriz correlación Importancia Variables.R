###############################################################################
# Script para matriz de correlación con todas las variables numéricas disponibles
###############################################################################
# Librerías
library(dplyr)
library(corrplot)

# Suponiendo que tu dataframe final se llama "df_calendar" y contiene las columnas
# que has usado en los diferentes scripts. Revisamos qué columnas tiene:
names(df_calendar)

# EJEMPLO de selección manual de variables relevantes.
# Incluye aquí TODAS las columnas numéricas que quieras ver en la matriz,
# asegurándote de que existan realmente en df_calendar (en minúsculas/mayúsculas correctas).
df_for_corr <- df_calendar %>%
  select(
    Factor_Imprevisibilidad,
    `Nº.curvas`,
    `Nº.rectas`,
    `Nº.zonas.de.DRS`,
    downforce_importance,
    drag_importance,
    # braking_importance,      # Descomenta si la columna existe en tu df_calendar
    # cornering_importance,    # Descomenta si la columna existe en tu df_calendar
    Prob_Lluvia,
    param_score,
    Calificacion_Escuderia_offset,
    Calificacion_Piloto,
    AeroEfficiency,            # Descomenta si uniste estos valores a df_calendar
    EnginePower,               # idem
    MechanicalGrip,            # idem
    Score_Race                 # idem, si la usas
    # w_team                   # idem, si la usas y es numérico
  ) %>%
  # Filtrar solo las columnas que sean numéricas, por seguridad
  select_if(is.numeric)

# Si quieres ver qué variables has seleccionado y su clase:
str(df_for_corr)

# Calcular la matriz de correlación (ignora filas con NA)
cor_matrix <- cor(df_for_corr, use = "complete.obs")

# Visualizar la matriz de correlación con corrplot
corrplot(
  cor_matrix,
  method        = "color",   # estilo de visualización (color, circle, etc.)
  addCoef.col   = "black",   # mostrar coeficientes en negro
  type          = "upper",   # solo la mitad superior (opcional)
  order         = "hclust",  # ordenamiento por clustering jerárquico
  tl.col        = "black",   # color de etiquetas
  tl.srt        = 45,        # rotar etiquetas 45º
  number.cex    = 0.7        # tamaño de números en cada celda
)

