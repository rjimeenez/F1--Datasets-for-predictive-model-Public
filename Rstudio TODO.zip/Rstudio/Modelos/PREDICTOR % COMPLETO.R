###############################################################################
# 1) Librerías
###############################################################################
library(dplyr)
library(tidyr)
library(ggplot2)
library(randomForest)
library(reshape2)   

###############################################################################
# 2) Cargar y preparar datos de circuitos
###############################################################################
ruta_circuitos <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics_corrected.csv"
circuitos <- read.csv(ruta_circuitos, sep=",", stringsAsFactors=FALSE)

# Diferenciar 2 GP de EE.UU. (Vegas y Austin)
circuitos$Nombre.de.GP <- ifelse(
  circuitos$Ronda.de.Calendario == 19, "GP de Estados Unidos (Vegas)",
  ifelse(circuitos$Ronda.de.Calendario == 22, "GP de Estados Unidos (Austin)",
         circuitos$Nombre.de.GP)
)

# Ordenar por Ronda y factorizar
circuitos <- circuitos %>%
  arrange(Ronda.de.Calendario) %>%
  mutate(Periodo = factor(Nombre.de.GP, levels=unique(Nombre.de.GP)))

# Calcular Factor de imprevisibilidad (lluvia + S.C.)
circuitos$Factor_Imprevisibilidad <- as.numeric(sub("%","",circuitos$X..Lluvia))/100 +
  as.numeric(sub("%","",circuitos$Probabilidad.de.S.C....))/200

# Asignar fase de mejora antes de la gráfica
# Ejemplo: 1..4=Inicio, 5..8=Espana, 9..12=Gran_Bretana, 13..17=Hungria, 18..24=Las_Vegas
circuitos <- circuitos %>%
  mutate(Mejora = case_when(
    Ronda.de.Calendario < 5   ~ "Inicio",
    Ronda.de.Calendario < 9   ~ "Espana",
    Ronda.de.Calendario < 13  ~ "Gran_Bretana",
    Ronda.de.Calendario < 18  ~ "Hungria",
    TRUE                      ~ "Las_Vegas"
  ))

# Crear "Nº.PitStops" si no existe (valor default=2)
if(!"Nº.PitStops" %in% names(circuitos)){
  circuitos$`Nº.PitStops` <- 2
}

# Ajustar importancia de parámetros según características del circuito
# (número de curvas, rectas y zonas de DRS)
circuitos <- circuitos %>%
  mutate(
    total_sections = `Nº.curvas` + `Nº.rectas`,
    # Downforce: aumenta con la proporción de curvas
    downforce_importance = ifelse(total_sections > 0,
                                  0.3 + 0.4*(`Nº.curvas` / total_sections),
                                  0.5),
    # Drag: aumenta con la proporción de rectas y algo de DRS
    drag_importance = ifelse(total_sections > 0,
                             0.3 + 0.3*(`Nº.rectas` / total_sections) + 
                               0.1*( `Nº.zonas.de.DRS` / pmax(1,max(`Nº.zonas.de.DRS`,na.rm=TRUE)) ),
                             0.5),
    # Braking y cornering 
    braking_importance = ifelse(total_sections > 0,
                                0.4 + 0.2*(`Nº.curvas` / total_sections),
                                0.5),
    cornering_importance = ifelse(total_sections > 0,
                                  0.4 + 0.2*(`Nº.curvas` / total_sections),
                                  0.5)
  )

###############################################################################
# 3) Cargar datos de escuderías (constructors) y filtrar a 11
###############################################################################
ruta_wdc <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/WDC_Drivers_Constructors_corrected.csv"
df_wdc <- read.csv(ruta_wdc, sep=";", stringsAsFactors=FALSE)

# Filtrar constructores
if("Categoría" %in% names(df_wdc)){
  df_wdc <- subset(df_wdc, `Categoría`=="Constructor")
} else if("Categoria" %in% names(df_wdc)){
  df_wdc <- subset(df_wdc, Categoria=="Constructor")
} else {
  stop("No existe columna 'Categoria' o 'Categoría'.")
}
df_wdc$Equipo <- df_wdc$Nombre

# Seleccionar solo las 11 escuderías de 2025
equipos_2025 <- c("McLaren-Mercedes","Ferrari","Red Bull Racing-Honda RBPT","Mercedes",
                  "Aston Martin-Mercedes","Alpine-Renault","Williams-Mercedes",
                  "Kick Sauber","Haas-Ferrari","Racing Bulls","JIRO Racing")
df_wdc <- df_wdc[df_wdc$Equipo %in% equipos_2025, ]

# Agregar puntos ajustados
if("Puntos.Ajustados" %in% names(df_wdc)){
  df_team_points <- aggregate(df_wdc$Puntos.Ajustados,
                              by=list(df_wdc$Equipo),
                              FUN=sum, na.rm=TRUE)
  names(df_team_points) <- c("Equipo","Puntos_Ajustados")
} else {
  stop("No existe columna 'Puntos.Ajustados'.")
}

if(nrow(df_team_points)>0){
  max_puntos <- max(df_team_points$Puntos_Ajustados,na.rm=TRUE)
  if(is.finite(max_puntos) && max_puntos>0) {
    df_team_points$Puntos_Normalizados <- df_team_points$Puntos_Ajustados / max_puntos
  } else {
    df_team_points$Puntos_Normalizados <- 0
  }
} else {
  df_team_points$Puntos_Normalizados <- 0
}

###############################################################################
# 4) Parámetros técnicos de escuderías y evolución
###############################################################################
parametros_tecnicos <- data.frame(
  Equipo = c("McLaren-Mercedes","Ferrari","Red Bull Racing-Honda RBPT","Mercedes",
             "Aston Martin-Mercedes","Alpine-Renault","Williams-Mercedes","Kick Sauber",
             "Haas-Ferrari","Racing Bulls","JIRO Racing"),
  Calificacion_Inicial = c(75,70,72,67,61,55,60,58,54,54,65),
  Calificacion_Final   = c(78,72,76,70,66,56,62,59,57,58,70),
  AeroEfficiency       = c(0.77,0.70,0.74,0.67,0.59,0.53,0.58,0.56,0.52,0.54,0.67),
  EnginePower          = c(0.75,0.72,0.70,0.69,0.63,0.55,0.62,0.58,0.54,0.52,0.65),
  MechanicalGrip       = c(0.73,0.68,0.72,0.75,0.61,0.57,0.60,0.60,0.56,0.56,0.63)
) %>%
  mutate(
    # Evolución de calificaciones
    Inicio_base   = Calificacion_Inicial,
    Espana        = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.25,
    Gran_Bretana  = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.50,
    Hungria       = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.75,
    Las_Vegas     = Calificacion_Final
  )

df_calificacion <- full_join(parametros_tecnicos, df_team_points, by="Equipo")
df_calificacion$Puntos_Normalizados[is.na(df_calificacion$Puntos_Normalizados)] <- 0

###############################################################################
# 5) Evolución de calificaciones (para la predicción)
###############################################################################
df_evolucion <- df_calificacion[, c("Equipo","Inicio_base","Espana","Gran_Bretana","Hungria","Las_Vegas")]
names(df_evolucion)[2] <- "Inicio"

df_evolucion_long <- df_evolucion %>%
  pivot_longer(cols=c("Inicio","Espana","Gran_Bretana","Hungria","Las_Vegas"),
               names_to="Mejora",
               values_to="Calificacion_Escuderia") %>%
  mutate(Mejora=as.character(Mejora))

###############################################################################
# 6) Datos de pilotos y atributos
###############################################################################
# Se definen 22 pilotos (2 por cada equipo)
pilotos_atributos <- data.frame(
  Piloto = c(
    "Lando Norris","Oscar Piastri","Charles Leclerc","Lewis Hamilton",
    "Fernando Alonso","Lance Stroll","Max Verstappen","Liam Lawson",
    "George Russell","Kimi Antonelli","Alex Albon","Carlos Sainz",
    "Nico Hülkenberg","Gabriel Bortoleto","Pierre Gasly","Jack Doohan",
    "Yuki Tsunoda","Isack Hadjar","Oliver Bearman","Esteban Ocon",
    "Jaime Jiménez","Manuel López"
  ),
  Equipo = rep(parametros_tecnicos$Equipo, each=2),
  Calificacion = c(88,85,89,92,96,80,93,81,87,79,86,88,83,74,84,77,83,72,80,78,84,83),
  # Atributos en [0..100]
  Experiencia = c(88,85,89,92,96,80,93,81,87,79,86,88,83,74,84,77,83,72,80,78,84,83),
  HabilidadVolante = c(88,85,89,93,96,80,94,82,87,79,86,88,83,74,84,77,83,72,80,78,84,83),
  Reflejos = c(88,85,89,93,96,80,92,81,87,79,86,88,83,74,84,77,83,72,80,78,84,83),
  Ritmo = c(88,85,89,92,96,80,93,81,87,79,86,88,83,74,84,77,83,72,80,78,84,83)
) %>%
  rowwise() %>%
  mutate(MediaAtributos = round(mean(c(Experiencia,HabilidadVolante,Reflejos,Ritmo)))) %>%
  ungroup()

# Calculamos la calificación media del piloto por equipo (para la simulación)
pilotos_avg <- pilotos_atributos %>%
  group_by(Equipo) %>%
  summarise(Calificacion_Piloto = mean(Calificacion), .groups="drop")

###############################################################################
# 7) Unir evolución de escudería y calificación de pilotos
###############################################################################
base_calif <- df_evolucion_long %>%
  left_join(pilotos_avg, by="Equipo")

###############################################################################
# 8) Unir con la información de circuitos (por "Mejora")
###############################################################################
base_modelo <- suppressWarnings(
  base_calif %>%
    inner_join(circuitos, by="Mejora")
)

###############################################################################
# 9) Calcular Calificación_Total combinando técnica y piloto
###############################################################################
base_modelo <- base_modelo %>%
  mutate(
    # Calificación_Tecnica (ejemplo) combinando calif. de escudería con la importancia media
    Calificacion_Tecnica = Calificacion_Escuderia * ((downforce_importance + drag_importance)/2),
    
    # Peso dinámico del piloto (30..45% según imprevisibilidad)
    dynamic_pilot_weight = 0.30 + (Factor_Imprevisibilidad / max(Factor_Imprevisibilidad, na.rm=TRUE)) * 0.15,
    
    # Calificación_Total = (1 - w_piloto)*Calif_Tecnica + w_piloto*Calif_Piloto
    Calificacion_Total = Calificacion_Tecnica*(1 - dynamic_pilot_weight) +
      Calificacion_Piloto*dynamic_pilot_weight
  ) %>%
  mutate(TeamFactor = factor(Equipo))

###############################################################################
# 10) Eliminar filas con NA y limpiar niveles
###############################################################################
base_modelo <- base_modelo %>% 
  filter(!is.na(Calificacion_Total),
         !is.na(`Nº.curvas`),
         !is.na(`Nº.rectas`),
         !is.na(`Nº.zonas.de.DRS`),
         !is.na(Probabilidad.de.S.C....))

base_modelo <- droplevels(base_modelo)

###############################################################################
# 11) Generar variables simuladas para escenarios (Clasificación y Carrera)
###############################################################################
# Con algo de ruido y dependencia de downforce/drag
set.seed(123)
base_modelo <- base_modelo %>%
  mutate(
    # Para Clasificación
    Calificacion_Clasificacion = Calificacion_Total + (downforce_importance - 0.5)*5 +
      rnorm(n(),0,0.02*Calificacion_Total),
    
    # Para Carrera
    Calificacion_Carrera = Calificacion_Total + (drag_importance - 0.5)*5 +
      rnorm(n(),0,0.02*Calificacion_Total)
  )

###############################################################################
# 12) Softmax de las puntuaciones para que sumen 100% en cada GP
###############################################################################
softmax_func <- function(scores) {
  exps <- exp(scores - max(scores))  # para estabilidad numérica
  exps / sum(exps)
}

# Calculamos "score_qualy" y "score_race" a partir de la regresión
base_modelo <- base_modelo %>%
  mutate(
    score_qualy = Calificacion_Clasificacion,
    score_race  = Calificacion_Carrera
  )

# Para cada GP, convertimos esos scores en probabilidades que sumen 100%
df_soft <- base_modelo %>%
  group_by(Periodo) %>%
  do({
    tmp <- .
    # Vectores de score
    sq <- tmp$score_qualy
    sr <- tmp$score_race
    # Softmax
    pq <- softmax_func(sq)*100
    pr <- softmax_func(sr)*100
    sp <- (sq + sr)/2
    pp <- softmax_func(sp)*100
    
    tmp$Prob_Qualy_Softmax <- pq
    tmp$Prob_Race_Softmax  <- pr
    tmp$Prob_Podio_Softmax <- pp
    
    tmp
  }) %>%
  ungroup()

###############################################################################
# 13) Seleccionar Top 3 en cada GP según softmax
###############################################################################
resumen_qualy <- df_soft %>%
  group_by(Periodo) %>%
  slice_max(order_by=Prob_Qualy_Softmax, n=3) %>%
  ungroup()

resumen_race <- df_soft %>%
  group_by(Periodo) %>%
  slice_max(order_by=Prob_Race_Softmax, n=3) %>%
  ungroup()

resumen_podio <- df_soft %>%
  group_by(Periodo) %>%
  slice_max(order_by=Prob_Podio_Softmax, n=3) %>%
  ungroup()

###############################################################################
# 14) Graficar Top 3 (Clasificación, Carrera, Podio) con softmax
###############################################################################
colores_equipos <- c(
  "McLaren-Mercedes"         = "#FF8700",
  "Ferrari"                  = "#FF2800",
  "Red Bull Racing-Honda RBPT" = "#1C1C3C",
  "Mercedes"                 = "#008080",
  "Aston Martin-Mercedes"    = "#004225",
  "Alpine-Renault"           = "#87CEEB",
  "Williams-Mercedes"        = "#00008B",
  "Kick Sauber"              = "#32CD32",
  "Haas-Ferrari"             = "#8B0000",
  "Racing Bulls"             = "#4169E1",
  "JIRO Racing"              = "#FFD700"
)

g1 <- ggplot(resumen_qualy, aes(x=Periodo, y=Prob_Qualy_Softmax, fill=Equipo)) +
  geom_bar(stat="identity", position="dodge", color="black") +
  # Añadimos las etiquetas de valor (sin decimales) encima de cada barra
  geom_text(aes(label=round(Prob_Qualy_Softmax,0)),
            position=position_dodge(width=0.9),
            vjust=-0.3, size=3) +
  scale_fill_manual(values=colores_equipos) +
  scale_y_continuous(breaks=seq(0,100,10), limits=c(0,105)) +
  labs(title="Top 3 de Probabilidad de Pole por GP (Clasificación)",
       x="Gran Premio", y="Probabilidad (%)") +
  theme_minimal() +
  theme(axis.text.x=element_text(angle=45, hjust=1))

g2 <- ggplot(resumen_race, aes(x=Periodo, y=Prob_Race_Softmax, fill=Equipo)) +
  geom_bar(stat="identity", position="dodge", color="black") +
  # Etiquetas sin decimales
  geom_text(aes(label=round(Prob_Race_Softmax,0)),
            position=position_dodge(width=0.9),
            vjust=-0.3, size=3) +
  scale_fill_manual(values=colores_equipos) +
  scale_y_continuous(breaks=seq(0,100,10), limits=c(0,105)) +
  labs(title="Top 3 de Probabilidad de Victoria por GP (Carrera)",
       x="Gran Premio", y="Probabilidad (%)") +
  theme_minimal() +
  theme(axis.text.x=element_text(angle=45, hjust=1))

g3 <- ggplot(resumen_podio, aes(x=Periodo, y=Prob_Podio_Softmax, fill=Equipo)) +
  geom_bar(stat="identity", position="dodge", color="black") +
  # Etiquetas sin decimales
  geom_text(aes(label=round(Prob_Podio_Softmax,0)),
            position=position_dodge(width=0.9),
            vjust=-0.3, size=3) +
  scale_fill_manual(values=colores_equipos) +
  scale_y_continuous(breaks=seq(0,100,10), limits=c(0,105)) +
  labs(title="Top 3 de Probabilidad de Podio por GP",
       x="Gran Premio", y="Probabilidad (%)") +
  theme_minimal() +
  theme(axis.text.x=element_text(angle=45, hjust=1))

print(g1)
print(g2)
print(g3)

