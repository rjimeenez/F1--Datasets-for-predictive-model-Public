###############################################################################
# 1) Librerías
###############################################################################
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)
library(xgboost)     
library(gridExtra)   
library(grid)

###############################################################################
# 2) Cargar y preparar datos de circuitos
###############################################################################
ruta_circuitos <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics_corrected.csv"
circuitos <- read.csv(ruta_circuitos, sep=",", stringsAsFactors=FALSE)

# Ajustar nombres de GP en EE.UU.
circuitos$Nombre.de.GP <- ifelse(
  circuitos$Ronda.de.Calendario == 19, "GP de Estados Unidos (Vegas)",
  ifelse(circuitos$Ronda.de.Calendario == 22, "GP de Estados Unidos (Austin)",
         circuitos$Nombre.de.GP)
)

# Ordenar por Ronda y factorizar
circuitos <- circuitos %>%
  arrange(Ronda.de.Calendario) %>%
  mutate(Periodo = factor(Nombre.de.GP, levels=unique(Nombre.de.GP)))

# Calcular factor de imprevisibilidad (lluvia + S.C.)
circuitos$Factor_Imprevisibilidad <- as.numeric(gsub("%","", circuitos$X..Lluvia))/100 +
  as.numeric(gsub("%","", circuitos$Probabilidad.de.S.C....))/200

# Asignar fase de mejora (1..4=Inicio, 5..8=Espana, 9..12=Gran_Bretana, 13..17=Hungria, 18..24=Las_Vegas)
circuitos <- circuitos %>%
  mutate(Mejora = case_when(
    Ronda.de.Calendario < 5   ~ "Inicio",
    Ronda.de.Calendario < 9   ~ "Espana",
    Ronda.de.Calendario < 13  ~ "Gran_Bretana",
    Ronda.de.Calendario < 18  ~ "Hungria",
    TRUE                      ~ "Las_Vegas"
  ))

# Crear "Nº.PitStops" si no existe (valor default=2)
if(!"Nº.PitStops" %in% names(circuitos)){
  circuitos$`Nº.PitStops` <- 2
}

# Ajustar importancia de parámetros según características (nº de curvas, rectas, DRS, etc.)
circuitos <- circuitos %>%
  mutate(
    total_sections = `Nº.curvas` + `Nº.rectas`,
    # Downforce: aumenta con la proporción de curvas
    downforce_importance = ifelse(total_sections > 0,
                                  0.3 + 0.4*(`Nº.curvas` / total_sections),
                                  0.5),
    # Drag: aumenta con la proporción de rectas y algo de DRS
    drag_importance = ifelse(total_sections > 0,
                             0.3 + 0.3*(`Nº.rectas` / total_sections) + 
                               0.1*( `Nº.zonas.de.DRS` / pmax(1, max(`Nº.zonas.de.DRS`, na.rm=TRUE)) ),
                             0.5))

###############################################################################
# 3) Parámetros técnicos de escuderías y evolución
###############################################################################
parametros_tecnicos <- data.frame(
  Equipo = c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", 
             "Aston Martin-Mercedes", "Alpine-Renault", "Williams-Mercedes", 
             "Kick Sauber", "Haas-Ferrari", "Racing Bulls", "JIRO Racing"),
  Calificacion_Inicial = c(75, 70, 72, 67, 61, 55, 60, 58, 54, 54, 65),
  Calificacion_Final   = c(78, 72, 76, 70, 66, 56, 62, 59, 57, 58, 70),
  AeroEfficiency       = c(0.77, 0.70, 0.74, 0.67, 0.59, 0.53, 0.58, 0.56, 0.52, 0.54, 0.67),
  EnginePower          = c(0.75, 0.72, 0.70, 0.69, 0.63, 0.55, 0.62, 0.58, 0.54, 0.52, 0.65),
  MechanicalGrip       = c(0.73, 0.68, 0.72, 0.75, 0.61, 0.57, 0.60, 0.60, 0.56, 0.56, 0.63)
) %>%
  mutate(
    # Evolución de calificaciones
    Inicio_base   = Calificacion_Inicial,
    Espana        = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.25,
    Gran_Bretana  = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.50,
    Hungria       = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.75,
    Las_Vegas     = Calificacion_Final
  )

###############################################################################
# 4) Datos de pilotos (calificaciones originales)
###############################################################################
pilotos <- data.frame(
  Piloto = tools::toTitleCase(tolower(c(
    "Lando Norris","Oscar Piastri","Charles Leclerc","Lewis Hamilton",
    "Fernando Alonso","Lance Stroll","Max Verstappen","Liam Lawson",
    "George Russell","Kimi Antonelli","Alex Albon","Carlos Sainz",
    "Nico Hülkenberg","Gabriel Bortoleto","Pierre Gasly","Jack Doohan",
    "Yuki Tsunoda","Isack Hadjar","Oliver Bearman","Esteban Ocon",
    "Jaime Jiménez","Manuel López"
  ))),
  Equipo = c(
    "McLaren-Mercedes","McLaren-Mercedes","Ferrari","Ferrari",
    "Aston Martin-Mercedes","Aston Martin-Mercedes","Red Bull Racing-Honda RBPT","Red Bull Racing-Honda RBPT",
    "Mercedes","Mercedes","Williams-Mercedes","Williams-Mercedes",
    "Kick Sauber","Kick Sauber","Alpine-Renault","Alpine-Renault",
    "Racing Bulls","Racing Bulls","Haas-Ferrari","Haas-Ferrari",
    "JIRO Racing","JIRO Racing"
  ),
  Calificacion_Piloto = c(
    88,85, 89,92, 96,80, 93,81, 87,79, 86,88, 83,74, 84,77, 83,72, 80,78, 84,83
  )
)

###############################################################################
# 5) Generar dataset principal: 24 GPs x 22 pilotos
###############################################################################
df_calendar <- expand.grid(Ronda = 1:24, Piloto = pilotos$Piloto, stringsAsFactors = FALSE) %>%
  left_join(pilotos, by = "Piloto")

# Unir con la información de circuitos (por Ronda)
circuitos_sub <- circuitos %>%
  select(Ronda = Ronda.de.Calendario, NombreGP = Nombre.de.GP, Mejora, 
         PitStops = `Nº.PitStops`,
         Factor_Imprevisibilidad, `Nº.curvas`, `Nº.rectas`, `Nº.zonas.de.DRS`,
         downforce_importance, drag_importance)
df_calendar <- df_calendar %>%
  left_join(circuitos_sub, by = "Ronda")

# Unir con la evolución de la escudería según la fase ("Mejora")
df_evol <- parametros_tecnicos %>%
  select(Equipo, Inicio_base, Espana, Gran_Bretana, Hungria, Las_Vegas,
         AeroEfficiency, EnginePower, MechanicalGrip)
df_evol_long <- df_evol %>%
  pivot_longer(cols = c("Espana", "Gran_Bretana", "Hungria", "Las_Vegas"),
               names_to = "Mejora", values_to = "Calificacion_Escuderia") %>%
  rename(CalifBase = Inicio_base)
df_calendar <- df_calendar %>%
  left_join(df_evol_long, by = c("Equipo", "Mejora"))

###############################################################################
# 6) Ajuste “cero-suma” en cada GP
###############################################################################
df_calendar <- df_calendar %>%
  mutate(
    # Combinamos Aero/Engine con la importancia media
    param_score = (AeroEfficiency * downforce_importance +
                     EnginePower    * drag_importance)*10
  ) %>%
  group_by(Ronda) %>%
  mutate(
    mean_param = mean(param_score, na.rm = TRUE),
    offset = param_score - mean_param,
    Calificacion_Escuderia_offset = Calificacion_Escuderia + offset
  ) %>%
  ungroup()

###############################################################################
# 7) Calcular Calificación_Total con peso 70% vs 30%
###############################################################################
df_calendar <- df_calendar %>%
  mutate(
    Calificacion_Total = 0.70*Calificacion_Escuderia_offset + 0.30*Calificacion_Piloto
  )

###############################################################################
# 8) Compresión final a [80..90] para mayor rango
###############################################################################
range_min <- 80
range_max <- 90
CT_min <- min(df_calendar$Calificacion_Total, na.rm = TRUE)
CT_max <- max(df_calendar$Calificacion_Total, na.rm = TRUE)
den <- max(1e-4, (CT_max - CT_min))

df_calendar <- df_calendar %>%
  mutate(
    Calificacion_Total_esc = range_min + (Calificacion_Total - CT_min)/den*(range_max-range_min)
  )

###############################################################################
# 9) Generar Score_Race y entrenar XGBoost
###############################################################################
set.seed(123)
df_calendar <- df_calendar %>%
  mutate(
    # Con ruido leve (2% de la calif.)
    Score_Race = Calificacion_Total_esc + rnorm(n(), 0, 0.02*Calificacion_Total_esc)
  )

# Dataset de entrenamiento
train_data <- df_calendar %>%
  filter(!is.na(Score_Race)) %>%
  select(Score_Race,
         Factor_Imprevisibilidad,
         Curvas = `Nº.curvas`,
         Rectas = `Nº.rectas`,
         DRS = `Nº.zonas.de.DRS`,
         TechEsc = Calificacion_Escuderia_offset,
         Pilot = Calificacion_Piloto,
         ParamScore = param_score)

features <- as.matrix(train_data[, c("Factor_Imprevisibilidad", "Curvas", "Rectas", "DRS",
                                     "TechEsc", "Pilot", "ParamScore")])
labels <- train_data$Score_Race
dtrain <- xgb.DMatrix(data = features, label = labels)

params <- list(objective = "reg:squarederror", eta = 0.05, max_depth = 3)
xgb_model <- xgb.train(params = params, data = dtrain, nrounds = 70, verbose = 0)

# Predicción XGBoost y re-Compresión a [80..90]
pred_features <- df_calendar %>%
  mutate(
    Curvas = `Nº.curvas`,
    Rectas = `Nº.rectas`,
    DRS = `Nº.zonas.de.DRS`,
    TechEsc = Calificacion_Escuderia_offset,
    Pilot = Calificacion_Piloto,
    ParamScore = param_score
  ) %>%
  select(Factor_Imprevisibilidad, Curvas, Rectas, DRS, TechEsc, Pilot, ParamScore)

pred_mat <- as.matrix(pred_features)
pred_xgb <- predict(xgb_model, pred_mat)

xgb_min <- min(pred_xgb, na.rm = TRUE)
xgb_max <- max(pred_xgb, na.rm = TRUE)
den2    <- max(1e-4, (xgb_max - xgb_min))

df_calendar$Score_Race_xgb <- range_min + (pred_xgb - xgb_min)/den2*(range_max-range_min)

###############################################################################
# 10) Ajuste final sin bias, con ruido mayor para evitar tantos “0 puntos”
###############################################################################
final_sd <- 1.2  # Aumentamos el ruido final
set.seed(999)
df_calendar <- df_calendar %>%
  group_by(Ronda) %>%
  mutate(
    Score_Final = Score_Race_xgb + rnorm(n(), 0, final_sd)
  ) %>%
  arrange(desc(Score_Final), .by_group=TRUE) %>%
  mutate(Posicion_Final = row_number()) %>%
  ungroup()

###############################################################################
# 11) Asignar puntos F1 y generar clasificación final
###############################################################################
darPuntos <- function(pos) {
  case_when(
    pos==1 ~ 25,
    pos==2 ~ 18,
    pos==3 ~ 15,
    pos==4 ~ 12,
    pos==5 ~ 10,
    pos==6 ~ 8,
    pos==7 ~ 6,
    pos==8 ~ 4,
    pos==9 ~ 2,
    pos==10~ 1,
    TRUE   ~ 0
  )
}

df_calendar <- df_calendar %>%
  group_by(Ronda) %>%
  mutate(
    PuntosBase = darPuntos(Posicion_Final),
    ExtraFastLap = 0,  # sin bonus de vuelta rápida
    PuntosTot = PuntosBase + ExtraFastLap
  ) %>%
  ungroup()

# Clasificación final de pilotos
clasif_pilotos <- df_calendar %>%
  group_by(Piloto) %>%
  summarise(
    Equipo = first(Equipo),
    PuntosAcumulados = sum(PuntosTot, na.rm=TRUE),
    .groups="drop"
  ) %>%
  arrange(desc(PuntosAcumulados)) %>%
  mutate(PosFinal=row_number())

# Clasificación final de escuderías (suma de puntos de ambos pilotos)
clasif_equipos <- df_calendar %>%
  group_by(Equipo) %>%
  summarise(
    PuntosAcumulados = sum(PuntosTot, na.rm=TRUE),
    .groups="drop"
  ) %>%
  arrange(desc(PuntosAcumulados)) %>%
  mutate(PosFinal=row_number())

###############################################################################
# 12) Mostrar tablas finales
###############################################################################
tabla_pilotos <- tableGrob(clasif_pilotos)
tabla_equipos <- tableGrob(clasif_equipos)

grid.newpage()
grid.arrange(tabla_pilotos, nrow=1, top="Clasificación Final de Pilotos (XGBoost)")

grid.newpage()
grid.arrange(tabla_equipos, nrow=1, top="Clasificación Final de Escuderías (XGBoost)")
