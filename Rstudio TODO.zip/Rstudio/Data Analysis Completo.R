###############################################################################
# 1) Librerías
###############################################################################
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)    
library(xgboost)     
library(caret)       
library(ggpubr)
library(readr)

###############################################################################
# 2) Cargar y preparar datos de circuitos
###############################################################################
ruta_circuitos <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics_corrected.csv"
circuitos <- read.csv(ruta_circuitos, sep = ",", stringsAsFactors = FALSE)

# Ajustar nombres de GP en EE.UU. (Vegas y Austin)
circuitos$Nombre.de.GP <- ifelse(
  circuitos$Ronda.de.Calendario == 19, "GP de Estados Unidos (Vegas)",
  ifelse(circuitos$Ronda.de.Calendario == 22, "GP de Estados Unidos (Austin)",
         circuitos$Nombre.de.GP)
)

# Ordenar por Ronda y definir factor 'Periodo'
circuitos <- circuitos %>% 
  arrange(Ronda.de.Calendario) %>% 
  mutate(Periodo = factor(Nombre.de.GP, levels = unique(Nombre.de.GP)))

# Calcular Factor de imprevisibilidad (lluvia + % S.C.)
circuitos$Factor_Imprevisibilidad <- as.numeric(gsub("%", "", circuitos$X..Lluvia)) / 100 +
  as.numeric(gsub("%", "", circuitos$Probabilidad.de.S.C....)) / 200

# Crear la columna Prob_Lluvia (asegúrate que la columna X..Lluvia exista)
circuitos <- circuitos %>% 
  mutate(Prob_Lluvia = as.numeric(gsub("%", "", X..Lluvia)) / 100)

# Asignar fase de mejora según el calendario:
circuitos <- circuitos %>%
  mutate(Mejora = case_when(
    Ronda.de.Calendario < 5   ~ "Inicio",
    Ronda.de.Calendario < 9   ~ "Espana",
    Ronda.de.Calendario < 13  ~ "Gran_Bretana",
    Ronda.de.Calendario < 18  ~ "Hungria",
    TRUE                      ~ "Las_Vegas"
  ))

# Crear "Nº.PitStops" si no existe (default = 2)
if(!"Nº.PitStops" %in% names(circuitos)){
  circuitos$`Nº.PitStops` <- 2
}

# Importancia de parámetros del circuito
circuitos <- circuitos %>%
  mutate(
    total_sections = `Nº.curvas` + `Nº.rectas`,
    downforce_importance = ifelse(total_sections > 0,
                                  0.3 + 0.4 * (`Nº.curvas` / total_sections),
                                  0.5),
    drag_importance = ifelse(total_sections > 0,
                             0.3 + 0.3 * (`Nº.rectas` / total_sections) +
                               0.1 * (`Nº.zonas.de.DRS` / pmax(1, max(`Nº.zonas.de.DRS`, na.rm = TRUE))),
                             0.5),
    braking_importance = 0.5,
    cornering_importance = 0.5
  )

###############################################################################
# 3) Cargar datos de escuderías y filtrar a las 11 de 2025
###############################################################################
ruta_wdc <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/WDC_Drivers_Constructors_corrected.csv"
df_wdc <- read.csv(ruta_wdc, sep = ";", stringsAsFactors = FALSE)
if("Categoría" %in% names(df_wdc)){
  df_wdc <- subset(df_wdc, `Categoría` == "Constructor")
} else if("Categoria" %in% names(df_wdc)){
  df_wdc <- subset(df_wdc, Categoria == "Constructor")
} else {
  stop("La columna 'Categoría' o 'Categoria' no existe en el dataset.")
}
df_wdc$Equipo <- df_wdc$Nombre
equipos_2025 <- c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", 
                  "Aston Martin-Mercedes", "Alpine-Renault", "Williams-Mercedes", 
                  "Kick Sauber", "Haas-Ferrari", "Racing Bulls", "JIRO Racing")
df_wdc <- df_wdc[df_wdc$Equipo %in% equipos_2025, ]
if("Puntos.Ajustados" %in% names(df_wdc)){
  df_team_points <- aggregate(df_wdc$Puntos.Ajustados,
                              by = list(df_wdc$Equipo),
                              FUN = sum, na.rm = TRUE)
  names(df_team_points) <- c("Equipo", "Puntos_Ajustados")
} else {
  stop("La columna 'Puntos.Ajustados' no existe en el dataset.")
}
if(nrow(df_team_points) > 0){
  df_team_points$Puntos_Normalizados <- df_team_points$Puntos_Ajustados /
    max(df_team_points$Puntos_Ajustados, na.rm = TRUE)
} else {
  df_team_points$Puntos_Normalizados <- 0
}

###############################################################################
# 4) Parámetros técnicos de escuderías y evolución
###############################################################################
parametros_tecnicos <- data.frame(
  Equipo = c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", 
             "Aston Martin-Mercedes", "Alpine-Renault", "Williams-Mercedes", "Kick Sauber", 
             "Haas-Ferrari", "Racing Bulls", "JIRO Racing"),
  Calificacion_Inicial = c(75, 70, 72, 67, 61, 55, 60, 58, 54, 54, 65),
  Calificacion_Final   = c(78, 72, 76, 70, 66, 56, 62, 59, 57, 58, 70),
  AeroEfficiency       = c(0.77, 0.70, 0.74, 0.67, 0.59, 0.53, 0.58, 0.56, 0.52, 0.54, 0.67),
  EnginePower          = c(0.75, 0.72, 0.70, 0.69, 0.63, 0.55, 0.62, 0.58, 0.54, 0.52, 0.65),
  MechanicalGrip       = c(0.73, 0.68, 0.72, 0.65, 0.61, 0.57, 0.60, 0.60, 0.56, 0.56, 0.63)
) %>%
  mutate(
    Inicio_base   = Calificacion_Inicial,
    Espana        = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial) * 0.25,
    Gran_Bretana  = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial) * 0.50,
    Hungria       = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial) * 0.75,
    Las_Vegas     = Calificacion_Final
  )

###############################################################################
# 5) Convertir atributos de pilotos a [0..100]
###############################################################################
pilotos_atributos <- data.frame(
  Piloto = tools::toTitleCase(tolower(c(
    "Lando Norris", "Oscar Piastri", "Charles Leclerc", "Lewis Hamilton",
    "Fernando Alonso", "Lance Stroll", "Max Verstappen", "Liam Lawson",
    "George Russell", "Kimi Antonelli", "Alex Albon", "Carlos Sainz",
    "Nico Hülkenberg", "Gabriel Bortoleto", "Pierre Gasly", "Jack Doohan",
    "Yuki Tsunoda", "Isack Hadjar", "Oliver Bearman", "Esteban Ocon",
    "Jaime Jiménez", "Manuel López"
  ))),
  Equipo = c(
    "McLaren-Mercedes", "McLaren-Mercedes", "Ferrari", "Ferrari",
    "Aston Martin-Mercedes", "Aston Martin-Mercedes", "Red Bull Racing-Honda RBPT", "Red Bull Racing-Honda RBPT",
    "Mercedes", "Mercedes", "Williams-Mercedes", "Williams-Mercedes",
    "Kick Sauber", "Kick Sauber", "Alpine-Renault", "Alpine-Renault",
    "Racing Bulls", "Racing Bulls", "Haas-Ferrari", "Haas-Ferrari",
    "JIRO Racing", "JIRO Racing"
  ),
  Calificacion = c(88,85,89,92,96,80,93,81,87,79,86,88,83,74,84,77,83,72,80,78,84,83)
)
# Renombramos la columna para que se alinee con los cálculos posteriores
pilotos_atributos <- pilotos_atributos %>% rename(Calificacion_Piloto = Calificacion)
pilotos_atributos <- pilotos_atributos %>% mutate(across(Calificacion_Piloto, as.integer))

###############################################################################
# 6) Generar dataset principal y unir con circuitos y evolución
###############################################################################
df_calendar <- expand.grid(Ronda = 1:24, Piloto = pilotos_atributos$Piloto, stringsAsFactors = FALSE) %>%
  left_join(pilotos_atributos, by = "Piloto") %>%
  left_join(
    circuitos %>% 
      select(Ronda = Ronda.de.Calendario, NombreGP = Nombre.de.GP, Mejora,
             Factor_Imprevisibilidad, `Nº.curvas`, `Nº.rectas`, `Nº.zonas.de.DRS`,
             downforce_importance, drag_importance, Prob_Lluvia),
    by = "Ronda"
  )
df_evol_long <- parametros_tecnicos %>%
  pivot_longer(cols = c("Espana", "Gran_Bretana", "Hungria", "Las_Vegas"),
               names_to = "Mejora", values_to = "Calificacion_Escuderia") %>%
  rename(CalifBase = Inicio_base)
df_calendar <- df_calendar %>% left_join(df_evol_long, by = c("Equipo", "Mejora"))

###############################################################################
# 7) Calcular Calificación_Total y comprimir a [80,90]
###############################################################################
df_calendar <- df_calendar %>%
  mutate(
    param_score = (AeroEfficiency * downforce_importance + EnginePower * drag_importance) * 10,
    mean_param  = ave(param_score, Ronda, FUN = mean),
    offset      = param_score - mean_param,
    Calificacion_Escuderia_offset = Calificacion_Escuderia + offset,
    w_team = pmax(0.65 - 0.15 * Prob_Lluvia, 0.50),
    Calificacion_Total = w_team * Calificacion_Escuderia_offset + (1 - w_team) * Calificacion_Piloto
  )
range_min <- 80
range_max <- 90
CT_min <- min(df_calendar$Calificacion_Total, na.rm = TRUE)
CT_max <- max(df_calendar$Calificacion_Total, na.rm = TRUE)
denom <- max(0.0001, CT_max - CT_min)
df_calendar <- df_calendar %>%
  mutate(
    Calificacion_Total_esc = range_min + (Calificacion_Total - CT_min) / denom * (range_max - range_min)
  )

###############################################################################
# 8) Generar Score_Race (base para modelado) con muy poco ruido
###############################################################################
set.seed(123)
df_calendar <- df_calendar %>%
  mutate(
    Score_Race = Calificacion_Total_esc + rnorm(n(), 0, 0.001 * Calificacion_Total_esc)
  ) %>%
  drop_na(Score_Race, Factor_Imprevisibilidad, `Nº.curvas`, `Nº.rectas`, 
          `Nº.zonas.de.DRS`, Calificacion_Escuderia_offset, Calificacion_Piloto,
          param_score, Prob_Lluvia)

###############################################################################
# 9) Dividir datos y entrenar modelos (XGBoost y Random Forest)
###############################################################################
features <- c("Factor_Imprevisibilidad", "Nº.curvas", "Nº.rectas", "Nº.zonas.de.DRS",
              "downforce_importance", "drag_importance", "Calificacion_Piloto", "Calificacion_Escuderia_offset")
target <- "Calificacion_Total"
set.seed(123)
trainIndex <- createDataPartition(df_calendar[[target]], p = 0.7, list = FALSE)
train_data <- df_calendar[trainIndex, ]
test_data <- df_calendar[-trainIndex, ]
features_train <- as.matrix(train_data[, features])
labels_train <- train_data[[target]]
features_test <- as.matrix(test_data[, features])
labels_test <- test_data[[target]]
dtrain <- xgb.DMatrix(data = features_train, label = labels_train)
dtest  <- xgb.DMatrix(data = features_test, label = labels_test)

# XGBoost ajustado para un fit fino
params <- list(objective = "reg:squarederror", eta = 0.01, max_depth = 4,
               subsample = 0.8, colsample_bytree = 0.8)
xgb_model <- xgb.train(params = params, data = dtrain, nrounds = 250, verbose = 0)
pred_xgb_train <- predict(xgb_model, dtrain)
pred_xgb_test  <- predict(xgb_model, dtest)

# Modelo Random Forest
library(randomForest)
rf_model <- randomForest(as.formula(paste(target, "~", paste(features, collapse = "+"))), 
                         data = train_data, ntree = 200, mtry = 3)
pred_rf_train <- predict(rf_model, train_data)
pred_rf_test  <- predict(rf_model, test_data)

###############################################################################
# 10) Calcular métricas de evaluación
###############################################################################
calcular_metricas <- function(y_real, y_pred) {
  r2 <- cor(as.numeric(y_real), as.numeric(y_pred))^2
  mae <- mean(abs(y_pred - y_real))
  rmse <- sqrt(mean((y_pred - y_real)^2))
  mape <- mean(abs((y_real - y_pred) / y_real)) * 100
  c(R2 = r2, MAE = mae, RMSE = rmse, MAPE = mape)
}
metricas_xgb_train <- calcular_metricas(labels_train, pred_xgb_train)
metricas_xgb_test  <- calcular_metricas(labels_test, pred_xgb_test)
metricas_rf_train  <- calcular_metricas(train_data[[target]], pred_rf_train)
metricas_rf_test   <- calcular_metricas(test_data[[target]], pred_rf_test)

###############################################################################
# 11) Visualización de métricas (gráficas de barras)
###############################################################################
df_resultados <- data.frame(
  Modelo = rep(c("XGBoost", "Random Forest"), each = 4),
  Métrica = rep(c("R²", "MAE", "RMSE", "MAPE"), 2),
  Entrenamiento = c(metricas_xgb_train, metricas_rf_train),
  Prueba = c(metricas_xgb_test, metricas_rf_test)
)
p_train <- ggplot(df_resultados, aes(x = Métrica, y = Entrenamiento, fill = Modelo)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Comparación de Modelos - Train", y = "Valor") +
  theme_minimal()
p_test <- ggplot(df_resultados, aes(x = Métrica, y = Prueba, fill = Modelo)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Comparación de Modelos - Test", y = "Valor") +
  theme_minimal()
print(p_train)
print(p_test)

###############################################################################
# 12) Imprimir resultados en consola
###############################################################################
cat("=== Resultados XGBoost ===\n")
print(metricas_xgb_train)
print(metricas_xgb_test)
cat("\n=== Resultados Random Forest ===\n")
print(metricas_rf_train)
print(metricas_rf_test)