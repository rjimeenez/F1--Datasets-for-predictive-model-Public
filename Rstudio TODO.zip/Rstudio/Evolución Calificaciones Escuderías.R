# Cargar las librerías necesarias
library(ggplot2)
library(reshape2)
library(dplyr) # Para mejorar merge()

# Cargar los datos del archivo CSV
ruta_archivo <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/WDC_Drivers_Constructors_corrected.csv"
df_wdc <- read.csv(ruta_archivo, sep=";", stringsAsFactors=FALSE)

# Verificar los nombres de las columnas
print(names(df_wdc))

# Ajustar el nombre correcto de la columna de categoría
if ("Categoría" %in% names(df_wdc)) {
  df_wdc <- subset(df_wdc, `Categoría` == "Constructor")
} else if ("Categoria" %in% names(df_wdc)) {
  df_wdc <- subset(df_wdc, Categoría == "Constructor")
} else {
  stop("La columna 'Categoria' o 'Categoría' no existe en el dataset.")
}

# Ajustar la columna de equipo
df_wdc$Equipo <- df_wdc$Nombre

# Agrupar por equipo y sumar los puntos ajustados
if ("Puntos.Ajustados" %in% names(df_wdc)) {
  df_team_points <- aggregate(df_wdc$Puntos.Ajustados, by=list(df_wdc$Equipo), FUN=sum, na.rm=TRUE)
  names(df_team_points) <- c("Equipo", "Puntos_Ajustados")
} else {
  stop("La columna 'Puntos.Ajustados' no existe en el dataset.")
}

# Asegurar que haya datos antes de normalizar
if (nrow(df_team_points) > 0) {
  df_team_points$Puntos_Normalizados <- df_team_points$Puntos_Ajustados / max(df_team_points$Puntos_Ajustados, na.rm=TRUE)
} else {
  df_team_points$Puntos_Normalizados <- 0
}

# Definir parámetros técnicos de cada equipo
parametros_tecnicos <- data.frame(
  Equipo = c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", "Aston Martin-Mercedes", 
             "Alpine-Renault", "Williams-Mercedes", "Kick Sauber", "Haas-Ferrari", "Racing Bulls", "JIRO Racing"),
  Aerodinamica = c(85, 82, 88, 80, 75, 70, 65, 60, 58, 62, 78),
  Eficiencia_Mecanica = c(80, 78, 85, 77, 70, 65, 60, 58, 55, 60, 75),
  Desempeno_Motor = c(90, 85, 92, 88, 80, 70, 68, 65, 60, 67, 83),
  Gestion_Neumaticos = c(75, 70, 78, 72, 68, 60, 58, 55, 52, 57, 70),
  Evolucion_Desarrollo = c(80, 78, 85, 77, 70, 65, 60, 58, 55, 60, 75)
)

# Calcular la calificación técnica ponderada
parametros_tecnicos$Calificacion_Tecnica <- (parametros_tecnicos$Aerodinamica * 0.30) +
  (parametros_tecnicos$Eficiencia_Mecanica * 0.25) +
  (parametros_tecnicos$Desempeno_Motor * 0.20) +
  (parametros_tecnicos$Gestion_Neumaticos * 0.15) +
  (parametros_tecnicos$Evolucion_Desarrollo * 0.10)

# Unir datos técnicos con los puntos ajustados usando full_join para evitar merge vacío
df_calificacion <- full_join(parametros_tecnicos, df_team_points, by="Equipo")

# Verificar si el merge ha funcionado
print(df_calificacion)

# Asignar 0 a Puntos_Normalizados si hay valores NA
df_calificacion$Puntos_Normalizados[is.na(df_calificacion$Puntos_Normalizados)] <- 0

# Calcular calificación final
df_calificacion$Calificacion_Final <- (df_calificacion$Calificacion_Tecnica * 0.60) +
  (df_calificacion$Puntos_Normalizados * 0.40)

# Definir paquetes de mejoras
mejoras <- c(Espana=0.25, Gran_Bretana=0.50, Hungria=0.75, Las_Vegas=1.00)

df_evolucion <- df_calificacion[, c("Equipo", "Calificacion_Final")]
names(df_evolucion) <- c("Equipo", "Inicio")

df_evolucion$Espana <- df_evolucion$Inicio + mejoras["Espana"]
df_evolucion$Gran_Bretana <- df_evolucion$Espana + mejoras["Gran_Bretana"]
df_evolucion$Hungria <- df_evolucion$Gran_Bretana + mejoras["Hungria"]
df_evolucion$Las_Vegas <- df_evolucion$Hungria + mejoras["Las_Vegas"]

# Asegurar que todos los equipos están representados
df_evolucion <- df_evolucion[complete.cases(df_evolucion), ]

# Definir colores personalizados
colores_equipos <- c(
  "McLaren-Mercedes" = "#FF8700", "Ferrari" = "#FF2800", "Red Bull Racing-Honda RBPT" = "#1C1C3C", 
  "Mercedes" = "#008080", "Aston Martin-Mercedes" = "#004225", "Alpine-Renault" = "#87CEEB", 
  "Williams-Mercedes" = "#00008B", "Kick Sauber" = "#32CD32", "Haas-Ferrari" = "#8B0000", 
  "Racing Bulls" = "#4169E1", "JIRO Racing" = "#FFD700"
)

# Graficar la evolución de calificaciones
ggplot(melt(df_evolucion, id.vars = "Equipo"), aes(x = variable, y = value, group = Equipo, color = Equipo)) +
  geom_line(linewidth = 1) +
  geom_point(size = 3) +
  geom_segment(aes(xend = variable, yend = min(df_evolucion$Inicio, na.rm=TRUE)), linetype = "dashed", color = "gray50") +
  geom_text(aes(label = round(value, 1)), vjust = -1, size = 3) +
  scale_y_continuous(breaks = seq(40, 90, by = 5)) +
  scale_color_manual(values = colores_equipos) +
  labs(title = "Evolución de Calificación de Escuderías", x = "Gran Premio", y = "Calificación (%)") +
  theme_minimal() +
  theme(legend.text = element_text(size = 12), legend.title = element_text(size = 14), 
        legend.key.size = unit(1, "cm"), legend.position = "right")
