###############################################################################
# 1) Librerías
###############################################################################
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)   # melt
library(ggpubr)     # ggtexttable, table_cell_bg, table_cell_font, etc.

###############################################################################
# 2) Datos de circuitos (ejemplo)
###############################################################################
ruta_circuitos <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics_corrected.csv"
circuitos <- read.csv(ruta_circuitos, sep=",", stringsAsFactors=FALSE)

# Ajustar la fase de mejora antes de la gráfica:
# (p.ej. 1..4=Inicio, 5..8=Espana, 9..12=Gran_Bretana, 13..17=Hungria, 18..24=Las_Vegas)
circuitos <- circuitos %>%
  mutate(Mejora = case_when(
    Ronda.de.Calendario < 5   ~ "Inicio",
    Ronda.de.Calendario < 9   ~ "Espana",
    Ronda.de.Calendario < 13  ~ "Gran_Bretana",
    Ronda.de.Calendario < 18  ~ "Hungria",
    TRUE                      ~ "Las_Vegas"
  ))

###############################################################################
# 3) Cargar datos de constructores y filtrar 11 escuderías
###############################################################################
ruta_wdc <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/WDC_Drivers_Constructors_corrected.csv"
df_wdc <- read.csv(ruta_wdc, sep=";", stringsAsFactors=FALSE)

# Filtrar 'Constructor'
if("Categoría" %in% names(df_wdc)) {
  df_wdc <- subset(df_wdc, `Categoría`=="Constructor")
} else if("Categoria" %in% names(df_wdc)) {
  df_wdc <- subset(df_wdc, Categoria=="Constructor")
} else {
  stop("No existe columna 'Categoria' o 'Categoría' en dataset WDC.")
}

df_wdc$Equipo <- df_wdc$Nombre

equipos_2025 <- c("McLaren-Mercedes","Ferrari","Red Bull Racing-Honda RBPT","Mercedes",
                  "Aston Martin-Mercedes","Alpine-Renault","Williams-Mercedes",
                  "Kick Sauber","Haas-Ferrari","Racing Bulls","JIRO Racing")
df_wdc <- df_wdc[df_wdc$Equipo %in% equipos_2025, ]

# Agrupar y sumar Puntos.Ajustados
if("Puntos.Ajustados" %in% names(df_wdc)) {
  df_team_points <- aggregate(df_wdc$Puntos.Ajustados,
                              by=list(df_wdc$Equipo),
                              FUN=sum, na.rm=TRUE)
  names(df_team_points) <- c("Equipo","Puntos_Ajustados")
} else {
  stop("No existe columna 'Puntos.Ajustados'.")
}

if(nrow(df_team_points)>0) {
  df_team_points$Puntos_Normalizados <- df_team_points$Puntos_Ajustados /
    max(df_team_points$Puntos_Ajustados, na.rm=TRUE)
} else {
  df_team_points$Puntos_Normalizados <- 0
}

###############################################################################
# 4) Parámetros técnicos de escuderías 
###############################################################################
parametros_tecnicos <- data.frame(
  Equipo = c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", 
             "Aston Martin-Mercedes", "Alpine-Renault", "Williams-Mercedes", 
             "Kick Sauber", "Haas-Ferrari", "Racing Bulls", "JIRO Racing"),
  Calificacion_Inicial = c(75, 70, 72, 67, 61, 55, 60, 58, 54, 54, 65),
  Calificacion_Final   = c(78, 72, 76, 70, 66, 56, 62, 59, 57, 58, 70),
  AeroEfficiency       = c(0.77, 0.70, 0.74, 0.67, 0.59, 0.53, 0.58, 0.56, 0.52, 0.54, 0.67),
  EnginePower          = c(0.75, 0.72, 0.70, 0.69, 0.63, 0.55, 0.62, 0.58, 0.54, 0.52, 0.65),
  MechanicalGrip       = c(0.73, 0.68, 0.72, 0.65, 0.61, 0.57, 0.60, 0.60, 0.56, 0.56, 0.63)
) %>%
  mutate(
    Inicio_base   = Calificacion_Inicial,
    Espana        = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.25,
    Gran_Bretana  = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.50,
    Hungria       = Calificacion_Inicial + (Calificacion_Final - Calificacion_Inicial)*0.75,
    Las_Vegas     = Calificacion_Final
  )

# Unir con df_team_points
df_calificacion <- full_join(parametros_tecnicos, df_team_points, by="Equipo") %>%
  filter(Equipo %in% equipos_2025)

df_calificacion$Puntos_Normalizados[is.na(df_calificacion$Puntos_Normalizados)] <- 0

###############################################################################
# 5) Gráfica de evolución de calificaciones
###############################################################################
df_evolucion <- df_calificacion[, c("Equipo","Inicio_base","Espana","Gran_Bretana","Hungria","Las_Vegas")]
names(df_evolucion)[2] <- "Inicio"

df_evol_melt <- melt(df_evolucion, id.vars="Equipo")

colores_equipos <- c(
  "McLaren-Mercedes"         = "#FF8700",
  "Ferrari"                  = "#FF2800",
  "Red Bull Racing-Honda RBPT" = "#1C1C3C",
  "Mercedes"                 = "#008080",
  "Aston Martin-Mercedes"    = "#004225",
  "Alpine-Renault"           = "#87CEEB",
  "Williams-Mercedes"        = "#00008B",
  "Kick Sauber"              = "#32CD32",
  "Haas-Ferrari"             = "#8B0000",
  "Racing Bulls"             = "#4169E1",
  "JIRO Racing"              = "#FFD700"
)

ggplot(df_evol_melt, aes(x=variable, y=value, group=Equipo, color=Equipo)) +
  geom_line(linewidth=1) +
  geom_point(size=3) +
  geom_text(aes(label=round(value,1)), vjust=-1, size=3) +
  scale_y_continuous(breaks=seq(50,80,2), limits=c(50,80)) +
  scale_color_manual(values=colores_equipos) +
  labs(title="Evolución de Calificación de Escuderías (2025)",
       subtitle="Datos técnicos simulados sobre 5 fases clave del campeonato",
       x="Fase de Mejora", y="Calificación (%)",
       caption="Fuente: Elaboración propia con datos simulados") +
  theme_minimal() +
  theme(
    legend.text=element_text(size=12),
    legend.title=element_text(size=14),
    legend.key.size=unit(1,"cm"),
    legend.position="right"
  )

###############################################################################
# 6) Tabla final de escuderías
###############################################################################
# a) Preparamos df con columnas en orden: 
#    [Equipo, Calificacion_Inicial, Aero,Engine,Mech, Calificacion_Final]
df_tabla <- df_calificacion %>%
  select(
    Equipo,
    Calificacion_Inicial,
    AeroEfficiency,
    EnginePower,
    MechanicalGrip,
    Calificacion_Final
  ) %>%
  arrange(desc(Calificacion_Final))

# Convertimos a numeric enteros en las calificaciones
df_tabla$Calificacion_Inicial <- as.integer(df_tabla$Calificacion_Inicial)
df_tabla$Calificacion_Final   <- as.integer(df_tabla$Calificacion_Final)

# Formatear Aero,Engine,Mech a 2 decimales
df_tabla$AeroEfficiency <- sprintf("%.2f", df_tabla$AeroEfficiency)
df_tabla$EnginePower    <- sprintf("%.2f", df_tabla$EnginePower)
df_tabla$MechanicalGrip <- sprintf("%.2f", df_tabla$MechanicalGrip)

# b) Convertimos a ggtexttable
p_tabla <- ggtexttable(
  df_tabla,
  rows=NULL,
  theme=ttheme("classic", base_size=12)
)

# c) Pintar filas según el equipo (alpha=0.15)
n_filas <- nrow(df_tabla)
n_cols <- ncol(df_tabla)

for(i in seq_len(n_filas)) {
  eq <- df_tabla$Equipo[i]
  fillcolor <- if(eq %in% names(colores_equipos)) colores_equipos[[eq]] else "#FFFFFF"
  
  p_tabla <- table_cell_bg(
    p_tabla,
    row    = i+1,
    column = 1:n_cols,
    fill   = fillcolor,
    alpha  = 0.15
  )
}

# d) Poner en negrita las dos columnas de Calificación
for(i in seq_len(n_filas)) {
  p_tabla <- table_cell_font(
    p_tabla,
    row    = i+1,
    column = 2,
    face   = "bold"
  )
  p_tabla <- table_cell_font(
    p_tabla,
    row    = i+1,
    column = 6,
    face   = "bold"
  )
}

# e) Añadir título
p_tabla <- tab_add_title(
  p_tabla,
  text  = "Tabla de Escuderías con Parámetros Técnicos (2025)",
  face  = "bold",
  size  = 14
)

# f) Mostrar la tabla
print(p_tabla)

