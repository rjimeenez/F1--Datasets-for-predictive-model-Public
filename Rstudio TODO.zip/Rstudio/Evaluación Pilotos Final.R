###############################################################################
# 1) Librerías y colores
###############################################################################
library(dplyr)
library(ggplot2)
library(ggpubr)   
library(tools)   

# Definimos colores de equipo
colores_equipos <- c(
  "McLaren-Mercedes"         = "#FF8700",
  "Ferrari"                  = "#FF2800",
  "Red Bull Racing-Honda RBPT" = "#1C1C3C",
  "Mercedes"                 = "#008080",
  "Aston Martin-Mercedes"    = "#004225",
  "Alpine-Renault"           = "#87CEEB",
  "Williams-Mercedes"        = "#00008B",
  "Kick Sauber"              = "#32CD32",
  "Haas-Ferrari"             = "#8B0000",
  "Racing Bulls"             = "#4169E1",
  "JIRO Racing"              = "#FFD700"
)

###############################################################################
# 2) Data frame de pilotos con atributos
###############################################################################
pilotos_atributos <- data.frame(
  Piloto = toTitleCase(tolower(c(
    "Lando Norris","Oscar Piastri","Charles Leclerc","Lewis Hamilton",
    "Fernando Alonso","Lance Stroll","Max Verstappen","Liam Lawson",
    "George Russell","Kimi Antonelli","Alex Albon","Carlos Sainz",
    "Nico Hülkenberg","Gabriel Bortoleto","Pierre Gasly","Jack Doohan",
    "Yuki Tsunoda","Isack Hadjar","Oliver Bearman","Esteban Ocon",
    "Jaime Jiménez","Manuel López"
  ))),
  Equipo = c(
    "McLaren-Mercedes","McLaren-Mercedes","Ferrari","Ferrari",
    "Aston Martin-Mercedes","Aston Martin-Mercedes","Red Bull Racing-Honda RBPT","Red Bull Racing-Honda RBPT",
    "Mercedes","Mercedes","Williams-Mercedes","Williams-Mercedes",
    "Kick Sauber","Kick Sauber","Alpine-Renault","Alpine-Renault",
    "Racing Bulls","Racing Bulls","Haas-Ferrari","Haas-Ferrari",
    "JIRO Racing","JIRO Racing"
  ),
  # Calificación global (enteros)
  Calificacion = c(
    88,85, 89,92, 96,80, 93,81, 87,79,
    86,88, 83,74, 84,77, 83,72, 80,78,
    84,83
  ),
  # Atributos en [0..1], luego *100 => ~ Calificacion
  Experiencia = c(
    0.88,0.85, 0.89,0.92, 0.96,0.80, 0.93,0.81,
    0.87,0.79, 0.86,0.88, 0.83,0.74, 0.84,0.77,
    0.83,0.72, 0.80,0.78, 0.84,0.83
  ),
  HabilidadVolante = c(
    0.88,0.85, 0.89,0.93, 0.96,0.80, 0.94,0.82,
    0.87,0.79, 0.86,0.88, 0.83,0.74, 0.84,0.77,
    0.83,0.72, 0.80,0.78, 0.84,0.83
  ),
  Reflejos = c(
    0.88,0.85, 0.89,0.93, 0.96,0.80, 0.92,0.81,
    0.87,0.79, 0.86,0.88, 0.83,0.74, 0.84,0.77,
    0.83,0.72, 0.80,0.78, 0.84,0.83
  ),
  Ritmo = c(
    0.88,0.85, 0.89,0.92, 0.96,0.80, 0.93,0.81,
    0.87,0.79, 0.86,0.88, 0.83,0.74, 0.84,0.77,
    0.83,0.72, 0.80,0.78, 0.84,0.83
  )
)

###############################################################################
# 3) Convertir atributos a [0..100], reordenar
###############################################################################
pilotos_atributos <- pilotos_atributos %>%
  rowwise() %>%
  mutate(
    Experiencia       = as.integer(Experiencia * 100),
    HabilidadVolante  = as.integer(HabilidadVolante * 100),
    Reflejos          = as.integer(Reflejos * 100),
    Ritmo             = as.integer(Ritmo * 100)
  ) %>%
  ungroup() %>%
  # Calculamos una media interna para ordenar el gráfico
  mutate(
    TempMedia = as.integer(round(rowMeans(across(c(Experiencia,HabilidadVolante,Reflejos,Ritmo)))))
  ) %>%
  # Ordenar: mayor media, luego mayor calificación
  arrange(desc(TempMedia), desc(Calificacion))

###############################################################################
# 4) Gráfico de barras: ordenado por la media de atributos (TempMedia)
###############################################################################
p_barras <- ggplot(
  pilotos_atributos, 
  aes(x = reorder(Piloto, -TempMedia),
      y = TempMedia,
      fill = Equipo)) +
  geom_bar(stat="identity", width=0.7, color="black") +
  geom_text(aes(label=TempMedia), vjust=-0.3, size=3.5, fontface="bold") +
  scale_fill_manual(values = colores_equipos) +
  scale_y_continuous(limits=c(0,100), breaks=seq(0,100,5)) +
  labs(
    title="Calificación Media de Pilotos (2025)",
    x="Piloto", 
    y="Media de Atributos (%)"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle=90, vjust=0.5, hjust=1),
    plot.title  = element_text(face="bold", size=14)
  )

###############################################################################
# 5) Tabla coloreada con ggtexttable
###############################################################################
# Eliminamos la columna TempMedia y dejamos la calificación al final
tabla_df <- pilotos_atributos %>%
  select(
    Piloto, Equipo, 
    Experiencia, HabilidadVolante, Reflejos, Ritmo,
    Calificacion
  )

# Usamos ggtexttable para dibujar la tabla
p_tabla <- ggtexttable(
  tabla_df,
  rows = NULL, 
  theme = ttheme("classic", base_size=11)
)

# Recorremos filas para colorear
# - Para la última columna (Calificacion) la pondremos en negrita con table_cell_font
# - El alpha general de la fila lo reducimos un poco para que se lea mejor
n_filas <- nrow(tabla_df)
n_cols <- ncol(tabla_df)

for(i in seq_len(n_filas)) {
  eq <- tabla_df$Equipo[i]
  fillcolor <- if(eq %in% names(colores_equipos)) colores_equipos[[eq]] else "#FFFFFF"
  
  # Pintamos de col 1..(ncol-1) con alpha=0.15
  p_tabla <- table_cell_bg(
    p_tabla,
    row = i+1,  # la primera fila de datos es row=2 en ggtexttable
    column = 1:(n_cols-1),
    fill = fillcolor,
    alpha = 0.15
  )
  # Para la última columna => alpha=0.05
  p_tabla <- table_cell_bg(
    p_tabla,
    row = i+1,
    column = n_cols,
    fill = fillcolor,
    alpha = 0.05
  )
}

# Ponemos la última columna en negrita (Calificacion)
p_tabla <- table_cell_font(
  p_tabla,
  row = 2:(n_filas+1),
  column = n_cols,
  face = "bold"
)

# Añadimos un título
p_tabla <- tab_add_title(
  p_tabla,
  text = "Tabla de Pilotos con Atributos (2025)",
  face = "bold",
  size = 13
)

###############################################################################
# 6) Mostramos por separado: gráfico y tabla
###############################################################################
# a) Gráfico de barras
print(p_barras)

# b) Tabla
print(p_tabla)
