# Cargar librerías necesarias
library(ggplot2)
library(dplyr)
library(tidyr)

# Especificar la ruta del archivo
ruta_archivo <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics_corrected.csv"

# Leer el archivo
circuits_data <- read.csv(ruta_archivo, sep=",", header=TRUE, stringsAsFactors=FALSE, fileEncoding="UTF-8")

# Ver nombres de columnas para asegurarnos de usar los correctos
print(names(circuits_data))

# Convertir a formato numérico las columnas relevantes
circuits_data$Distancia <- as.numeric(gsub("[^0-9.]", "", circuits_data$Distancia.recorrida..km.))
circuits_data$Vueltas <- as.numeric(gsub("[^0-9.]", "", circuits_data$Nº.vueltas))
circuits_data$Curvas <- as.numeric(gsub("[^0-9.]", "", circuits_data$Nº.curvas))
circuits_data$Rectas <- as.numeric(gsub("[^0-9.]", "", circuits_data$Nº.rectas))

# Verificar si existe la columna correspondiente al nombre del circuito
if ("Nombre.de.GP" %in% names(circuits_data)) {
  circuits_data$NombreCircuito <- circuits_data$Nombre.de.GP
} else {
  stop("Error: No se encontró la columna con los nombres de los circuitos.")
}

# Asignar nombres específicos a los GP de Estados Unidos basados en "Ronda de Calendario"
circuits_data$NombreCircuito <- ifelse(
  circuits_data$Ronda.de.Calendario == 19, "GP de Estados Unidos (Vegas)",
  ifelse(circuits_data$Ronda.de.Calendario == 22, "GP de Estados Unidos (Austin)",
         circuits_data$Nombre.de.GP)  # Mantener los demás circuitos con su nombre original
)

# 1️⃣ **Gráfico de Barras: Comparación de Longitud de los Circuitos**
# Crear una nueva variable de clasificación de la distancia en rangos
circuits_data$Categoria_Distancia <- cut(
  circuits_data$Distancia,
  breaks = c(0, 300, 305, 310, Inf),  # Rango de longitudes
  labels = c("Menos de 300 km", "Entre 300 y 305 km", "Entre 305 y 310 km", "Más de 310 km"),
  include.lowest = TRUE
)

# Asignar colores a los rangos
colores_distancia <- c(
  "Menos de 300 km" = "red",
  "Entre 300 y 305 km" = "orange",
  "Entre 305 y 310 km" = "yellow",
  "Más de 310 km" = "green"
)

# **Gráfico de Barras: Comparación de Longitud de los Circuitos**
ggplot(circuits_data, aes(x = Distancia, y = reorder(NombreCircuito, Distancia), fill = Categoria_Distancia)) +
  geom_bar(stat = "identity", color = "black") +
  scale_fill_manual(values = colores_distancia, name = "Categoría de Distancia") + 
  labs(title = "Distancia de Circuitos", 
       x = "Distancia (km)", 
       y = "Circuito") +
  theme(axis.text.y = element_text(size = 10, hjust = 1))

# 2️⃣ **Gráfico de Barras: Número de Vueltas por Circuito**
# Crear una nueva variable de clasificación de las vueltas en rangos
circuits_data$Categoria_Vueltas <- cut(
  circuits_data$Vueltas,
  breaks = c(0, 50, 60, 70, Inf),  # Rango de vueltas
  labels = c("Menos de 50 vueltas", "Entre 50 y 60 vueltas", "Entre 60 y 70 vueltas", "Más de 70 vueltas"),
  include.lowest = TRUE
)

# Asignar colores a los rangos
colores_vueltas <- c(
  "Menos de 50 vueltas" = "red",
  "Entre 50 y 60 vueltas" = "orange",
  "Entre 60 y 70 vueltas" = "yellow",
  "Más de 70 vueltas" = "green"
)

# **Gráfico de Barras: Número de Vueltas por Circuito**
ggplot(circuits_data, aes(x = Vueltas, y = reorder(NombreCircuito, Vueltas), fill = Categoria_Vueltas)) +
  geom_bar(stat = "identity", color = "black") +
  scale_fill_manual(values = colores_vueltas, name = "Categoría de Vueltas") + 
  labs(title = "Número de Vueltas por Circuito", 
       x = "Número de Vueltas", 
       y = "Circuito") +
  theme(axis.text.y = element_text(size = 10, hjust = 1))

# 3️⃣ **Gráfico Boxplot: Distribución del Número de Curvas y Rectas**
circuits_long <- circuits_data %>%
  pivot_longer(cols = c(Curvas, Rectas), names_to = "Tipo", values_to = "Cantidad")

ggplot(circuits_long, aes(x = Tipo, y = Cantidad, fill = Tipo)) +
  geom_boxplot() +
  labs(title = "Distribución del Número de Curvas y Rectas por Circuito", x = "Tipo", y = "Cantidad") +
  theme(legend.position = "none")

# 4️⃣ **Gráfico Relacional: Distancia vs Número de Vueltas**
ggplot(circuits_data, aes(x = Distancia, y = Vueltas, color = NombreCircuito)) +
  geom_point(size = 4, alpha = 0.8) +  
  geom_smooth(method = "lm", se = FALSE, linetype = "dashed", color = "black") +  # Tendencia esperada
  scale_color_manual(values = rainbow(nrow(circuits_data)), name = "Circuito") +  # Diferenciar circuitos por color
  labs(title = "Relación entre la Distancia del Circuito y el Número de Vueltas",
       x = "Distancia del Circuito (km)",
       y = "Número de Vueltas") +
  theme_minimal() +
  theme(legend.position = "right")  # Ubicar la leyenda a la derecha

# Opcional: Resaltar circuitos extremos
extremos <- circuits_data %>% filter(NombreCircuito %in% c("GP de Mónaco 2025", "GP de Zandvoort 2025", "GP de Bélgica 2025"))
ggplot(circuits_data, aes(x = Distancia, y = Vueltas, color = NombreCircuito)) +
  geom_point(size = 4, alpha = 0.8) +  
  geom_point(data = extremos, aes(x = Distancia, y = Vueltas), size = 6, shape = 21, fill = "red", color = "black") +  
  geom_smooth(method = "lm", se = FALSE, linetype = "dashed", color = "black") +  
  scale_color_manual(values = rainbow(nrow(circuits_data)), name = "Circuito") +
  labs(title = "Relación entre la Distancia del Circuito y el Número de Vueltas",
       x = "Distancia del Circuito (km)",
       y = "Número de Vueltas") +
  theme_minimal() +
  theme(legend.position = "right")  # Ubicar la leyenda a la derecha


