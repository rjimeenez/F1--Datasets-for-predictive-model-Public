# Cargar las librerías necesarias
library(ggplot2)

# Cargar los datos del archivo CSV
ruta_archivo <- "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/WDC_Drivers_Constructors_corrected.csv"
df_wdc <- read.csv(ruta_archivo, sep=";", stringsAsFactors=FALSE)

# Filtrar solo la categoría "Constructor"
df_wdc <- subset(df_wdc, Categoría == "Constructor")

# Ajustar la columna de equipo (en algunos casos, los nombres están en la columna "Nombre")
df_wdc$Equipo <- df_wdc$Nombre

# Agrupar por equipo y sumar los puntos ajustados
df_team_points <- aggregate(df_wdc$Puntos.Ajustados, by=list(df_wdc$Equipo), FUN=sum)
names(df_team_points) <- c("Equipo", "Puntos_Ajustados")

# Normalizar los puntos ajustados entre 0 y 1
df_team_points$Puntos_Normalizados <- df_team_points$Puntos_Ajustados / max(df_team_points$Puntos_Ajustados)

# Definir victorias históricas de cada escudería
victorias <- data.frame(
  Equipo = c("McLaren-Mercedes", "Ferrari", "Red Bull Racing-Honda RBPT", "Mercedes", "Aston Martin-Mercedes", 
             "Alpine-Renault", "Williams-Mercedes", "Alfa Romeo-Ferrari", "Haas-Ferrari", "Visa Cash App RB", "JIRO Racing"),
  Victorias = c(189, 248, 123, 163, 5, 144, 117, 11, 0, 2, 0)
)

# Normalizar victorias entre 0 y 1
victorias$Victorias_Normalizadas <- victorias$Victorias / max(victorias$Victorias)

# Definir calificaciones iniciales deseadas
calificaciones_deseadas <- data.frame(
  Equipo = c("McLaren-Mercedes", "Red Bull Racing-Honda RBPT", "Ferrari", "Mercedes", "Aston Martin-Mercedes", 
             "Williams-Mercedes", "Alfa Romeo-Ferrari", "Alpine-Renault", "Visa Cash App RB", "Haas-Ferrari", "JIRO Racing"),
  Calificacion_Inicial = c(75, 72, 70, 67, 61, 60, 58, 55, 54, 54, 65),
  Calificacion_Final = c(78, 76, 72, 70, 66, 62, 59, 56, 58, 57, 70)
)

# Unir puntos normalizados y victorias con calificaciones deseadas
df_calificacion <- merge(calificaciones_deseadas, df_team_points, by="Equipo", all.x=TRUE)
df_calificacion <- merge(df_calificacion, victorias, by="Equipo", all.x=TRUE)

# Definir paquetes de mejoras
mejoras <- c(Espana=0.25, Gran_Bretana=0.50, Hungria=0.75, Las_Vegas=1.00)

df_evolucion <- df_calificacion[, c("Equipo", "Calificacion_Inicial")]
names(df_evolucion) <- c("Equipo", "Inicio")

df_evolucion$Espana <- df_evolucion$Inicio + mejoras["Espana"]
df_evolucion$Gran_Bretana <- df_evolucion$Espana + mejoras["Gran_Bretana"]
df_evolucion$Hungria <- df_evolucion$Gran_Bretana + mejoras["Hungria"]
df_evolucion$Las_Vegas <- df_evolucion$Equipo

# Ajustar valores finales
df_evolucion$Las_Vegas <- calificaciones_deseadas$Calificacion_Final[match(df_evolucion$Equipo, calificaciones_deseadas$Equipo)]

# Graficar la evolución de calificaciones
melted_df <- reshape2::melt(df_evolucion, id.vars = "Equipo")

ggplot(melted_df, aes(x = variable, y = value, group = Equipo, color = Equipo)) +
  geom_line() +
  geom_point() +
  labs(title = "Evolución de Calificación de Escuderías", x = "Gran Premio", y = "Calificación (%)") +
  theme_minimal()

