# Race Engine

Repo for experimenting with simulating F1 races in python.

Uses custom tkinter for the UI

## Preview

![Preview](images/preview.PNG)

![Preview2](images/preview2.PNG)
