# -*- coding: utf-8 -*-
"""
Created on Wed Jan  8 09:46:56 2025

@author: rjime
"""

import pandas as pd
import numpy as np
import os

# Cargar los archivos de datos
compuestos_file_path = "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Compuestos/compuestos_neumaticos_f1.xlsx"
circuits_file_path = "C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BDDD/Propias/Circuits_specifics.xlsx"

# Leer los archivos Excel
compuestos_df = pd.read_excel(compuestos_file_path)
circuits_df = pd.read_excel(circuits_file_path)

# Extraer los datos de Bahréin como referencia
bahrain_data = circuits_df[circuits_df['Nombre de GP'].str.contains("Baréin", case=False, na=False)].iloc[0]

# Convertir a valores numéricos, asignando 0 solo si es necesario
bahrain_laps = pd.to_numeric(bahrain_data['Nº vueltas'], errors='coerce')
bahrain_avg_lap_time = pd.to_numeric(bahrain_data['Tiempo de vuelta medio en carrera Año anterior'], errors='coerce')

# Imputar valores manualmente solo si son NaN
if pd.isna(bahrain_laps):
    bahrain_laps = 0
if pd.isna(bahrain_avg_lap_time):
    bahrain_avg_lap_time = 0

# Validación de valores
print(f"Nº vueltas: {bahrain_laps}, Tiempo de vuelta: {bahrain_avg_lap_time}")

# Actualizar datos de duración y diferencia de tiempo para los demás GPs
for index, row in compuestos_df.iterrows():
    # Saltar Bahréin
    if "Baréin" in row['Circuito']:
        continue

    # Buscar datos del circuito correspondiente
    circuit_info = circuits_df[circuits_df['Nombre de GP'] == row['Circuito']].iloc[0]

    # Convertir cada valor de la fila de circuitos a numérico de forma individual
    circuit_info['Nº vueltas'] = pd.to_numeric(circuit_info['Nº vueltas'], errors='coerce')
    circuit_info['Tiempo de vuelta medio en carrera Año anterior'] = pd.to_numeric(circuit_info['Tiempo de vuelta medio en carrera Año anterior'], errors='coerce')
    circuit_info['Nº curvas'] = pd.to_numeric(circuit_info['Nº curvas'], errors='coerce')
    circuit_info['Nº zonas de DRS'] = pd.to_numeric(circuit_info['Nº zonas de DRS'], errors='coerce')

    # Imputar valores faltantes con 0 para evitar errores en cálculos
    if pd.isna(circuit_info['Nº vueltas']):
        circuit_info['Nº vueltas'] = 0
    if pd.isna(circuit_info['Tiempo de vuelta medio en carrera Año anterior']):
        circuit_info['Tiempo de vuelta medio en carrera Año anterior'] = 0
    if pd.isna(circuit_info['Nº curvas']):
        circuit_info['Nº curvas'] = 0
    if pd.isna(circuit_info['Nº zonas de DRS']):
        circuit_info['Nº zonas de DRS'] = 1  # Evitar divisiones por cero

    # Comparar características del circuito con Bahréin
    laps_ratio = circuit_info['Nº vueltas'] / bahrain_laps if bahrain_laps != 0 else 1
    avg_lap_time_ratio = circuit_info['Tiempo de vuelta medio en carrera Año anterior'] / bahrain_avg_lap_time if bahrain_avg_lap_time != 0 else 1
    curves_ratio = circuit_info['Nº curvas'] / bahrain_data['Nº curvas'] if bahrain_data['Nº curvas'] != 0 else 1
    drs_ratio = circuit_info['Nº zonas de DRS'] / bahrain_data['Nº zonas de DRS'] if bahrain_data['Nº zonas de DRS'] != 0 else 1

    # Ajustar duración del neumático basándose en vueltas y curvas
    new_duration = int(np.round(row['Duración Estimada (Vueltas)'] * (laps_ratio * curves_ratio)))
    compuestos_df.at[index, 'Duración Estimada (Vueltas)'] = new_duration

    # Ajustar diferencias de tiempo (valores pequeños)
    base_diff = pd.to_numeric(row['Dif. con C3 (s)'], errors='coerce')
    if pd.isna(base_diff):
        base_diff = 0  # Evitar errores si el valor no es numérico

    new_diff = base_diff * (avg_lap_time_ratio + (curves_ratio - drs_ratio) * 0.1)
    compuestos_df.at[index, 'Dif. con C3 (s)'] = round(new_diff, 3)

    # Ajustar diferencias con otros compuestos proporcionalmente
    compuestos_df.at[index, 'Dif. con C2 (s)'] = round(new_diff * 1.05, 3)
    compuestos_df.at[index, 'Dif. con C1 (s)'] = round(new_diff * 1.1, 3)
    compuestos_df.at[index, 'Dif. con CI (s)'] = round(new_diff * 1.3, 3)
    compuestos_df.at[index, 'Dif. con CW (s)'] = round(new_diff * 1.5, 3)

# Guardar el archivo modificado en la carpeta "Propias"
save_directory = r"C:/Users/rjime/Desktop/TFG- BA/Anteproyecto/Fuentes de las BBDD/Propias"

# Crear la carpeta si no existe
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

# Ruta de guardado
modified_file_path = os.path.join(save_directory, "Compuestos_Neumaticos_F1_corrected.xlsx")

# Guardar el archivo
compuestos_df.to_excel(modified_file_path, index=False, engine="openpyxl")

# Confirmación de guardado
print(f"Archivo guardado correctamente en: {modified_file_path}")
