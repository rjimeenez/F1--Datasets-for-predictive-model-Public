# Instructions for contributing to this repository

Only web development related things accepeted here. 
It means code and projects can be merged here any who is beginner to the github community and wants to contribute and get the swags, they are free to contribute And github related contents or git-commands can be also accepted here.


## Hacktoberfest Guidelines

This repository was not updated since a long time, so I have opened some issues and intend to complete this small project by the end of HacktoberFest. So I would encourage people to take up this challenge and participate in HacktoberFest to win Free Tshirt and Laptop Stickers.


## Room for Improvement

We are all humans and we always strive towards something better. Open new issues, find other problems and feel free to ask.

## Contributors

We will adding the names of anyone who contributes to this project here.
