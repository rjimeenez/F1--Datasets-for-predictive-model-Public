buildscript {
    repositories {
        gradlePluginPortal()
        mavenCentral()
    }
}
